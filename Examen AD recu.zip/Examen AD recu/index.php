<?php
// Database connection settings
require_once '../config.php';

// Fetch counts for summary
$playersCount = 0; // Replace with actual query to count players
$gamesCount = 0; // Replace with actual query to count games
$partidasCount = 0; // Replace with actual query to count partidas

// Display the main page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Dashboard</title>
</head>
<body>
    <h1>Management Dashboard</h1>
    <p>Players: <?php echo $playersCount; ?></p>
    <p>Games: <?php echo $gamesCount; ?></p>
    <p>Partidas: <?php echo $partidasCount; ?></p>

    <h2>Manage</h2>
    <ul>
        <li><a href="players/manage.php">Manage Players</a></li>
        <li><a href="games/manage.php">Manage Games</a></li>
        <li><a href="partidas/manage.php">Manage Partidas</a></li>
    </ul>
</body>
</html>