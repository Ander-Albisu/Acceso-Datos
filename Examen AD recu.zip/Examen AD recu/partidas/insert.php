<?php
// insert.php - Form for inserting a new partida

// Include database configuration
include '../../config.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $game_id = $_POST['game_id'];
    $player_id = $_POST['player_id'];

    // Insert new partida into the database
    $sql = "INSERT INTO partidas (name, game_id, player_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $name, $game_id, $player_id);

    if ($stmt->execute()) {
        echo "New partida created successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch games and players for dropdowns
$games = $conn->query("SELECT id, name FROM games");
$players = $conn->query("SELECT id, name FROM players");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Partida</title>
</head>
<body>
    <h1>Insert New Partida</h1>
    <form method="POST" action="">
        <label for="name">Partida Name:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="game_id">Select Game:</label>
        <select id="game_id" name="game_id" required>
            <?php while ($row = $games->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
            <?php endwhile; ?>
        </select><br>

        <label for="player_id">Select Player:</label>
        <select id="player_id" name="player_id" required>
            <?php while ($row = $players->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
            <?php endwhile; ?>
        </select><br>

        <input type="submit" value="Insert Partida">
    </form>
</body>
</html>