<?php
// delete.php - Handles the deletion of a partida based on its ID

require_once '../../config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Create a database connection
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the delete statement
    $stmt = $conn->prepare("DELETE FROM partidas WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Partida deleted successfully.";
    } else {
        echo "Error deleting partida: " . $conn->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "No ID provided for deletion.";
}
?>