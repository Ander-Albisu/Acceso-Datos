<?php
// update.php for managing partidas

require_once '../../config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM partidas WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);
    $partida = $stmt->fetch();

    if (!$partida) {
        die("Partida not found.");
    }
} else {
    die("ID not specified.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newField = $_POST['newField']; // Replace with actual field names
    $query = "UPDATE partidas SET field_name = ? WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$newField, $id]);
    header("Location: manage.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Partida</title>
</head>
<body>
    <h1>Update Partida</h1>
    <form method="POST">
        <label for="newField">Field Name:</label>
        <input type="text" id="newField" name="newField" value="<?php echo htmlspecialchars($partida['field_name']); ?>" required>
        <button type="submit">Update</button>
    </form>
    <a href="manage.php">Cancel</a>
</body>
</html>