# PHP Project Documentation

## Overview
This PHP project is designed to manage players, games, and partidas in a structured manner. It provides a user-friendly interface for performing CRUD (Create, Read, Update, Delete) operations on each entity.

## Project Structure
```
php-project
├── src
│   ├── index.php          # Main entry point of the application
│   ├── players            # Directory for player management
│   │   ├── manage.php     # Displays list of players
│   │   ├── insert.php     # Form to add a new player
│   │   ├── update.php     # Form to update player details
│   │   └── delete.php     # Handles player deletion
│   ├── games              # Directory for game management
│   │   ├── manage.php     # Displays list of games
│   │   ├── insert.php     # Form to add a new game
│   │   ├── update.php     # Form to update game details
│   │   └── delete.php     # Handles game deletion
│   ├── partidas           # Directory for partida management
│   │   ├── manage.php     # Displays list of partidas
│   │   ├── insert.php     # Form to add a new partida
│   │   ├── update.php     # Form to update partida details
│   │   └── delete.php     # Handles partida deletion
├── README.md              # Project documentation
└── config.php             # Database configuration settings
```

## Setup Instructions
1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Configure the `config.php` file with your database connection settings.
4. Open `src/index.php` in your web browser to access the application.

## Functionality
- **Players Management**: View, add, update, and delete players.
- **Games Management**: View, add, update, and delete games.
- **Partidas Management**: View, add, update, and delete partidas.
- **Summary Control**: The index page displays a summary of the total number of players, games, and partidas played.

This project serves as a foundational application for managing sports-related data and can be expanded with additional features as needed.