<?php


require_once '../../config.php';

if (isset($_GET['id'])) {
    $gameId = $_GET['id'];


    $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    $stmt = $conn->prepare("DELETE FROM games WHERE id = ?");
    $stmt->bind_param("i", $gameId);

    if ($stmt->execute()) {
        echo "Game deleted successfully.";
    } else {
        echo "Error deleting game: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "No game ID provided.";
}
?>