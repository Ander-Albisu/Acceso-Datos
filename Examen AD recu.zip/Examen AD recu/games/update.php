<?php
// update.php - Update Game Details

require_once '../../config.php';

if (isset($_GET['id'])) {
    $gameId = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM games WHERE id = ?");
    $stmt->execute([$gameId]);
    $game = $stmt->fetch();

    if (!$game) {
        die("Game not found.");
    }
} else {
    die("No game ID provided.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];

    $stmt = $pdo->prepare("UPDATE games SET name = ?, description = ? WHERE id = ?");
    $stmt->execute([$name, $description, $gameId]);

    header("Location: manage.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Game</title>
</head>
<body>
    <h1>Update Game</h1>
    <form method="POST">
        <label for="name">Game Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($game['name']); ?>" required>
        <br>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo htmlspecialchars($game['description']); ?></textarea>
        <br>
        <input type="submit" value="Update Game">
    </form>
    <a href="manage.php">Cancel</a>
</body>
</html>