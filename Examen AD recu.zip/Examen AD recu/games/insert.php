<?php


require_once '../../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $gameName = $_POST['game_name'];
    $gameDescription = $_POST['game_description'];

 
    $stmt = $pdo->prepare("INSERT INTO games (name, description) VALUES (?, ?)");
    if ($stmt->execute([$gameName, $gameDescription])) {
        echo "New game added successfully!";
    } else {
        echo "Error adding game.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Game</title>
</head>
<body>
    <h1>Insert New Game</h1>
    <form method="POST" action="">
        <label for="game_name">Game Name:</label>
        <input type="text" id="game_name" name="game_name" required>
        <br>
        <label for="game_description">Game Description:</label>
        <textarea id="game_description" name="game_description" required></textarea>
        <br>
        <input type="submit" value="Add Game">
    </form>
    <a href="manage.php">Back to Game Management</a>
</body>
</html>