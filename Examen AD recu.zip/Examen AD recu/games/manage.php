<?php

require_once '../../config.php';

$query = "SELECT * FROM games";
$result = $conn->query($query);


$games = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $games[] = $row;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Games</title>
</head>
<body>
    <h1>Manage Games</h1>
    <a href="insert.php">Insert New Game</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Genre</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($games)): ?>
                <tr>
                    <td colspan="4">No games found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($games as $game): ?>
                    <tr>
                        <td><?php echo $game['id']; ?></td>
                        <td><?php echo $game['name']; ?></td>
                        <td><?php echo $game['genre']; ?></td>
                        <td>
                            <a href="update.php?id=<?php echo $game['id']; ?>">Update</a>
                            <a href="delete.php?id=<?php echo $game['id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>