<?php
// Include database configuration
include '../../config.php';

// Fetch players from the database
$query = "SELECT * FROM players";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Players</title>
</head>
<body>
    <h1>Manage Players</h1>
    <a href="insert.php">Insert New Player</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Actions</th>
        </tr>
        <?php while ($player = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $player['id']; ?></td>
            <td><?php echo $player['name']; ?></td>
            <td>
                <a href="update.php?id=<?php echo $player['id']; ?>">Update</a>
                <a href="delete.php?id=<?php echo $player['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>