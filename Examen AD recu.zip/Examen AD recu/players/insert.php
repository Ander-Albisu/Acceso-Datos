<?php
// insert.php - Form for inserting a new player into the database

require_once '../../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $team = $_POST['team'];

    $stmt = $pdo->prepare("INSERT INTO players (name, age, team) VALUES (?, ?, ?)");
    if ($stmt->execute([$name, $age, $team])) {
        echo "Player added successfully!";
    } else {
        echo "Error adding player.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Player</title>
</head>
<body>
    <h1>Insert New Player</h1>
    <form method="POST" action="">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <br>
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" required>
        <br>
        <label for="team">Team:</label>
        <input type="text" id="team" name="team" required>
        <br>
        <input type="submit" value="Add Player">
    </form>
    <a href="manage.php">Back to Player Management</a>
</body>
</html>