<?php
// delete.php - Handles the deletion of a player based on their ID

require_once '../../config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Prepare the SQL statement to delete the player
    $stmt = $pdo->prepare("DELETE FROM players WHERE id = :id");
    $stmt->bindParam(':id', $id);
    
    if ($stmt->execute()) {
        echo "Player deleted successfully.";
    } else {
        echo "Error deleting player.";
    }
} else {
    echo "No player ID provided.";
}
?>